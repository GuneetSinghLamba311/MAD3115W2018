//
//  ViewController.swift
//  Day1IOSFundamental(20-feb-2018)
//
//  Created by MacStudent on 2018-02-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var TextField: UITextField!
    
    @IBOutlet weak var Label: UILabel!
    @IBOutlet weak var PasswordTextField: UITextField!
    @IBOutlet weak var EmailtextField: UITextField!
    
    
    @IBAction func GoButton_Action(_ sender: Any) {
        if PasswordTextField.text == "123456"
        {
            self.Label.alpha = 1
            UIView.animate(withDuration: 0.5, delay: 3, options: .curveEaseOut, animations: {
                self.Label.center.x -= self.view.bounds.width
                self.Label.text  =  "\(self.TextField.text!) successfully logged IN"
            }, completion: nil)
        }
            let alert = UIAlertController(title: "User Information", message: "\(EmailtextField.text!)", preferredStyle: .actionSheet)

            alert.addAction(UIAlertAction(title: "YES", style: .default, handler: nil))
            alert.addAction(UIAlertAction(title: "NO", style: .default, handler: nil))
            alert.addAction(UIAlertAction(title: "MAYBE", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.Label.alpha = 0
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}



