//
//  Customcell.swift
//  Day4IosProgramming
//
//  Created by Guneet Singh Lamba on 23/02/18.
//  Copyright © 2018 Guneet Singh Lamba. All rights reserved.
//

import UIKit

class Customcell: UITableViewCell {

    @IBOutlet weak var Name_Label: UILabel!
    @IBOutlet weak var Regular_Label: UILabel!
    @IBOutlet weak var Regular_Price: UILabel!
    @IBOutlet weak var Special_Price: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
   
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
