//
//  MenuItems.swift
//  Day4IosProgramming
//
//  Created by Guneet Singh Lamba on 23/02/18.
//  Copyright © 2018 Guneet Singh Lamba. All rights reserved.
//

import Foundation

class MenuItems

{
    var foodmenuItems:[String] = ["Peporoni pizza","Onion Pizza","farmHouse Pizza","Chicken Pizza","Tomato pizza","Soft drinks","Fries"]
    var price:[Double] = [10.11,12.00,7.88,9.00,8.00,23.12,15.89]
    var specialPrice:[Bool] = [false,true,false,false,true,false,true]
    
}
