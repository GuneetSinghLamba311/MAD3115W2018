//
//  ViewController.swift
//  Day8iosProgramming_Maps
//
//  Created by Guneet Singh Lamba on 01/03/18.
//  Copyright © 2018 Guneet Singh Lamba. All rights reserved.
//

import UIKit
import MapKit
class ViewController: UIViewController {

    @IBOutlet weak var MyMapView: MKMapView!
    
    let lambtonCollege = CLLocation(latitude: 43.773257, longitude: -79.335899)
    let RegionRadius:CLLocationAccuracy = 100
  
    override func viewDidLoad() {
        super.viewDidLoad()
        MyMapView.mapType = MKMapType.standard
        centreMapOnLocation(location: lambtonCollege, title: "Lambton College", subtitle: "265 YorkLand Blvd")
   
        
    }
    
    func centreMapOnLocation(location:CLLocation,title:String,subtitle:String) {
        
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,RegionRadius, RegionRadius)
        MyMapView.setRegion(coordinateRegion, animated: true)
        
    // Put an annotation on the location
        let Annotation:MKPointAnnotation = MKPointAnnotation()
        Annotation.coordinate = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude)
        Annotation.title = title
        Annotation.subtitle = subtitle
        MyMapView.addAnnotation(Annotation)
        
        }
}


