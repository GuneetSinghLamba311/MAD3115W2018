//
//  ViewController.swift
//  Day8IosProgramming_Maps2
//
//  Created by Guneet Singh Lamba on 01/03/18.
//  Copyright © 2018 Guneet Singh Lamba. All rights reserved.
//

import UIKit
import MapKit
class ViewController: UIViewController {
    // Get current Location
    
    @IBOutlet weak var myMapView: MKMapView!
    
    let RegionRadius:CLLocationDistance = 300
    let LocationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
      myMapView.mapType = MKMapType.mutedStandard
        LocationManager.delegate = self
        LocationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        LocationManager.requestAlwaysAuthorization()
        LocationManager.requestWhenInUseAuthorization()
        
        if  (CLLocationManager.locationServicesEnabled()) {
            
         LocationManager.startUpdatingLocation()
            }
        
        }
    func centreMapOnLocation(location:CLLocation,title:String,subtitle:String) {
        
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,RegionRadius, RegionRadius)
        myMapView.setRegion(coordinateRegion, animated: true)
        
        // Put an annotation on the location
        let Annotation:MKPointAnnotation = MKPointAnnotation()
        Annotation.coordinate = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude)
        Annotation.title = title
        Annotation.subtitle = subtitle
        myMapView.addAnnotation(Annotation)
        
    }
}


extension ViewController: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error.localizedDescription)
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse {
            LocationManager.requestLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        if locations.first != nil {
            print("location\(locations)")
        }
        centreMapOnLocation(location: LocationManager.location!, title: "Current Location", subtitle: "")
    }
}
    


