//
//  ViewController.swift
//  Day3IosSwiftProgramming
//
//  Created by Guneet Singh Lamba on 22/02/18.
//  Copyright © 2018 Guneet Singh Lamba. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate {
 
    

    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var DatePicker: UIDatePicker!
    @IBOutlet weak var CityPicker: UIPickerView!
    @IBOutlet weak var vehicleType: UITextField!
    @IBOutlet weak var vehicleNumber: UITextField!
    @IBOutlet weak var carplatenumber: UITextField!
    @IBOutlet weak var phonenumber: UITextField!
    @IBOutlet weak var password: UITextField!
    
var SelectedCityIndex:Int = 0
    var cityList:[String] = ["Vancouver","Toronto","Ottawa","Calgary","Windsor","Admenton","Brampton","Winnipeg"]
    
  
    @IBAction func Register_Action(_ sender: Any) {
   
        print("Running")
        displayvalues()
}
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return cityList.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return cityList[row]
    }
    
    func displayvalues() {
        self.SelectedCityIndex = self.CityPicker.selectedRow(inComponent: 0)
        let allData:String = "\(self.name.text!) \n \(self.email.text!) \n\(self.DatePicker.date) \n \(self.cityList[SelectedCityIndex]) \n \(self.phonenumber.text!)"
        let infoAlert = UIAlertController(title: "VerifyYourDetails", message: allData, preferredStyle: .actionSheet)
            infoAlert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: {_ in self.welcome()}))
            self.present(infoAlert, animated: true)
    }
    
    func welcome() {
        let welcomeSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let welcomeVC = welcomeSB.instantiateViewController(withIdentifier: "welcome") as! WelcomeViewController
        
        welcomeVC.Cname = name.text!
        welcomeVC.Cemail = email.text!
        welcomeVC.Cphonenumber = phonenumber.text!
        welcomeVC.Cvehicletype = vehicleType.text!
     
        
        
        navigationController?.pushViewController(welcomeVC, animated: true)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.CityPicker.delegate = self
        self.CityPicker.dataSource = self
    
    }


}

