//
//  WelcomeViewController.swift
//  Day3IosSwiftProgramming
//
//  Created by Guneet Singh Lamba on 22/02/18.
//  Copyright © 2018 Guneet Singh Lamba. All rights reserved.
//

import UIKit

class WelcomeViewController: UIViewController {

    var Cname:String = "ABC"
    var Cemail:String = "bg"
    var Cphonenumber:String = "57463"
    var Cvehicletype:String = "type1"
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var vehicletype: UITextField!
    @IBOutlet weak var phonenumber: UITextField!
    @IBOutlet weak var Date: UILabel!
    @IBOutlet weak var City: UILabel!

    
    override func viewWillAppear(_ animated: Bool) {
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action:   #selector(displayValues))
        self.navigationItem.rightBarButtonItem = doneButton
    
    }
    @objc func displayValues() {
        
        performSegue(withIdentifier: "table", sender: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    name.text = Cname
    email.text = Cemail
    phonenumber.text = Cphonenumber
    vehicletype.text = Cvehicletype
    
      
    }

  

}
